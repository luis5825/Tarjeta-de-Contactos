import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:mihojadevida/presentacion/screen/details_screen.dart';
import 'package:mihojadevida/presentacion/screen/home_screen.dart';

/// Configuración del enrutamiento de la aplicación utilizando GoRouter.
///
/// Este archivo centraliza la gestión de las rutas, incluyendo las transiciones
/// y los nombres de las rutas.
final GoRouter appRouter = GoRouter(
  // La ruta inicial que se carga al iniciar la aplicación.
  initialLocation: '/',
  routes: [
    /// Ruta para la pantalla de inicio (`/`).
    ///
    /// Utiliza una transición personalizada al salir para que la pantalla se
    /// deslice ligeramente hacia la izquierda (`-0.2`) mientras la siguiente
    /// pantalla entra.
    GoRoute(
      path: '/',
      name: HomeScreen.name,
      pageBuilder: (context, state) {
        return CustomTransitionPage(
          key: state.pageKey,
          child: const HomeScreen(),
          // `transitionsBuilder` define cómo se anima la página.
          transitionsBuilder: (context, animation, secondaryAnimation, child) {
            // Animación de salida: se activa cuando se navega *hacia* otra ruta.
            // La pantalla se mueve un 20% hacia la izquierda (`-0.2`).
            const begin = Offset(0.0, 0.0);
            const end = Offset(-0.2, 0.0);
            final tween = Tween(begin: begin, end: end);
            final offsetAnimation = secondaryAnimation.drive(tween);

            return SlideTransition(
              position: offsetAnimation,
              child: child,
            );
          },
        );
      },
    ),

    /// Ruta para la pantalla de detalles (`/details`).
    ///
    /// Esta ruta tiene dos animaciones: una para la entrada (`animation`) y otra
    /// para la salida (`secondaryAnimation`).
    GoRoute(
      path: '/details',
      name: DetailsScreen.name,
      pageBuilder: (context, state) {
        return CustomTransitionPage(
          key: state.pageKey,
          child: const DetailsScreen(),
          transitionsBuilder: (context, animation, secondaryAnimation, child) {
            // Animación de entrada: la pantalla se desliza desde la derecha
            // con un efecto elástico (`Curves.elasticOut`).
            final enterTween = Tween(
                    begin: const Offset(1.0, 0.0), end: const Offset(0.0, 0.0))
                .chain(CurveTween(curve: Curves.elasticOut));
            final enterAnimation = animation.drive(enterTween);

            // Animación de salida: la pantalla se desliza hacia la derecha.
            // Se usa cuando se presiona el botón de 'atrás'.
            final exitTween = Tween(
                begin: const Offset(0.0, 0.0), end: const Offset(1.0, 0.0));
            final exitAnimation = secondaryAnimation.drive(exitTween);

            // Se combinan ambas transiciones.
            // `enterAnimation` se aplica al widget `child` de la página actual.
            // `exitAnimation` se aplica cuando la página actual se va.
            return SlideTransition(
              position: exitAnimation,
              child: SlideTransition(
                position: enterAnimation,
                child: child,
              ),
            );
          },
        );
      },
    ),
  ],
);
