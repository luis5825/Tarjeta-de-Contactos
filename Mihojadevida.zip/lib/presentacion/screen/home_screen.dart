import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:mihojadevida/presentacion/screen/details_screen.dart';

/// La pantalla de inicio de la aplicación.
///
/// Este widget es un [StatelessWidget] que muestra una imagen de fondo,
/// un título y un botón para navegar a la pantalla de detalles.
class HomeScreen extends StatelessWidget {
  /// El nombre estático de la ruta para la navegación.
  static const name = 'home-screen';
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        // El [Stack] permite superponer widgets, en este caso,
        // la imagen de fondo y el contenido del centro.
        children: [
          // 1. La imagen de fondo.
          // El [Container] con un [DecorationImage] es la forma ideal
          // de poner una imagen como fondo de un widget.
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                // Asegúrate de que la ruta de la imagen en tu archivo pubspec.yaml
                // sea correcta y que la imagen exista en esa ubicación.
                image: AssetImage('assets/imagenes/fondo_Home.jpg'),
                fit: BoxFit.cover, // Cubre todo el espacio disponible.
              ),
            ),
          ),

          // 2. El contenido de la pantalla.
          // El [Center] asegura que la columna con el texto y el botón
          // esté centrada vertical y horizontalmente.
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // El título de la aplicación.
                const Text(
                  "Mi hoja de vida",
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                // Espacio entre el título y el botón.
                const SizedBox(height: 40),
                // El botón para navegar.
                FilledButton(
                  onPressed: () {
                    // Navega a la ruta con el nombre 'details-screen' usando go_router.
                    // Esto hace que la navegación sea más segura y fácil de refactorizar.
                    context.goNamed(DetailsScreen.name);
                  },
                  child: const Text("Ver Hoja de Vida"),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
