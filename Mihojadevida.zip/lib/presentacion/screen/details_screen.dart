import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

/// La pantalla principal para mostrar la vista de la hoja de vida.
///
/// Esta clase es responsable de renderizar el diseño principal de la pantalla,
/// adaptándose a dispositivos móviles y de escritorio. Utiliza el paquete
/// go_router para la navegación.
class DetailsScreen extends StatelessWidget {
  /// Nombre de la ruta estática para la navegación.
  static const String name = 'details-screen';
  const DetailsScreen({super.key});

  // Nueva paleta de colores basada en la imagen de la hoja de vida
  static const Color _backgroundColor = Color(0xFFF0F0F0); // Blanco grisáceo
  static const Color _cardColor = Color(0xFFE0E0E0); // Gris claro
  static const Color _accentColor =
      Color(0xFF555555); // Gris oscuro para los íconos
  static const Color _textColor =
      Color(0xFF333333); // Negro casi total para el texto

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _backgroundColor,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              // Botón para volver a la pantalla de inicio.
              Align(
                alignment: Alignment.topLeft,
                child: IconButton(
                  icon: const Icon(Icons.home_outlined),
                  color: _textColor,
                  iconSize: 32,
                  onPressed: () {
                    // Navega a la ruta principal '/' usando go_router.
                    context.go('/');
                  },
                ),
              ),
              // Renderiza el diseño según el tamaño de la pantalla.
              if (MediaQuery.of(context).size.width < 600) _buildMobileLayout(),
              if (MediaQuery.of(context).size.width >= 600)
                _buildDesktopLayout(),
            ],
          ),
        ),
      ),
    );
  }

  /// Construye el diseño para pantallas de escritorio (ancho >= 600).
  ///
  /// Crea una `Row` con dos columnas: una para la información personal
  /// y otra para la experiencia y estudios.
  Widget _buildDesktopLayout() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Columna izquierda con información personal.
        Container(
          width: 300,
          color: _cardColor,
          padding: const EdgeInsets.all(32.0),
          child: _buildPersonalInformationSection(),
        ),
        // Columna derecha con experiencia y estudios, que se expande para ocupar
        // el espacio restante.
        const Expanded(
          child: SingleChildScrollView(
            padding: EdgeInsets.all(32.0),
            child: _RightColumnContent(),
          ),
        ),
      ],
    );
  }

  /// Construye el diseño para pantallas móviles (ancho < 600).
  ///
  /// Crea una `Column` que apila la información personal, la experiencia
  /// y los estudios verticalmente.
  Widget _buildMobileLayout() {
    return const Column(
      children: [
        _PersonalInformationMobile(),
        _RightColumnContent(),
      ],
    );
  }

  /// Construye el widget de la sección de información personal.
  ///
  /// Este widget contiene la foto de perfil, el nombre, los datos de contacto,
  /// enlaces a redes sociales y la lista de habilidades.
  Widget _buildPersonalInformationSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const CircleAvatar(
          radius: 80,
          // Nota: '1ccc43a42' es un marcador de posición.
          // Deberías reemplazarlo con una URL de imagen o un AssetImage.
          backgroundImage: NetworkImage('1ccc43a42'),
        ),
        const SizedBox(height: 16),
        const Text(
          'Luis Eduardo',
          style: TextStyle(
            color: _textColor,
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          'Cartagena Romero',
          style: TextStyle(
            color: _textColor.withOpacity(0.8),
            fontSize: 18,
          ),
        ),
        Divider(color: _textColor.withOpacity(0.5)),
        const _ContactInfo(),
        Divider(color: _textColor.withOpacity(0.5)),
        const Text(
          'Redes y enlaces',
          style: TextStyle(
            color: _textColor,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        const _SocialLink(label: 'www.facebook.com/...'),
        Divider(color: _textColor.withOpacity(0.5)),
        const Text(
          'Habilidades',
          style: TextStyle(
            color: _textColor,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        const _SkillsList(),
      ],
    );
  }
}

/// Widget para mostrar la información de contacto.
///
/// Contiene una lista de `_ContactItem` para cada dato de contacto.
class _ContactInfo extends StatelessWidget {
  const _ContactInfo();

  @override
  Widget build(BuildContext context) {
    return const Column(
      children: [
        _ContactItem(
            icon: Icons.calendar_today, text: '14 diciembre 2003, Apartadó'),
        _ContactItem(icon: Icons.phone, text: '+57 302 398 0489'),
        _ContactItem(icon: Icons.email, text: 'cartagenaluis58@gmail.com'),
        _ContactItem(icon: Icons.location_on, text: 'Chigorodó'),
        _ContactItem(icon: Icons.credit_card, text: 'C.C: 1.037.116.023'),
      ],
    );
  }
}

/// Widget para un elemento de contacto individual.
///
/// Recibe un ícono y un texto para mostrar un solo dato de contacto.
class _ContactItem extends StatelessWidget {
  /// El ícono a mostrar.
  final IconData icon;

  /// El texto del dato de contacto.
  final String text;

  const _ContactItem({required this.icon, required this.text});

  static const Color _accentColor = Color(0xFF555555); // Gris oscuro
  static const Color _textColor = Color(0xFF333333); // Negro

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        children: [
          Icon(icon, color: _accentColor, size: 18),
          const SizedBox(width: 10),
          Expanded(
              child: Text(text,
                  style: TextStyle(color: _textColor.withOpacity(0.8)))),
        ],
      ),
    );
  }
}

/// Widget para mostrar un enlace social.
///
/// Recibe un `label` para mostrar el texto del enlace.
class _SocialLink extends StatelessWidget {
  /// El texto del enlace a mostrar.
  final String label;

  const _SocialLink({required this.label});

  static const Color _textColor = Color(0xFF333333); // Negro

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const Icon(Icons.link, color: _textColor, size: 18),
        const SizedBox(width: 10),
        Text(
          label,
          style: const TextStyle(
            color: _textColor,
            decoration: TextDecoration.underline,
          ),
        ),
      ],
    );
  }
}

/// Widget para mostrar la lista de habilidades.
///
/// Utiliza `Wrap` para acomodar los `_SkillChip` en múltiples líneas.
class _SkillsList extends StatelessWidget {
  const _SkillsList();

  @override
  Widget build(BuildContext context) {
    return const Wrap(
      spacing: 8.0,
      runSpacing: 8.0,
      children: [
        _SkillChip(label: 'Atención al cliente'),
        _SkillChip(label: 'Manejo de word'),
        _SkillChip(label: 'Manejo de excel'),
        _SkillChip(label: 'Soporte'),
        _SkillChip(label: 'Redacción de contenido'),
        _SkillChip(label: 'Creatividad'),
        _SkillChip(label: 'Comunicación efectiva'),
        _SkillChip(label: 'Resolución de problemas'),
        _SkillChip(label: 'Adaptabilidad'),
        _SkillChip(label: 'Organización y gestión'),
      ],
    );
  }
}

/// Widget para un chip de habilidad individual.
///
/// Representa una habilidad específica con un `Chip` y un `label`.
class _SkillChip extends StatelessWidget {
  /// El texto de la habilidad a mostrar.
  final String label;

  const _SkillChip({required this.label});

  static const Color _cardColor = Color(0xFFE0E0E0); // Gris claro
  static const Color _textColor = Color(0xFF333333); // Negro
  static const Color _borderColor = Color(0xFFB0B0B0); // Gris medio

  @override
  Widget build(BuildContext context) {
    return Chip(
      label: Text(label, style: const TextStyle(color: _textColor)),
      backgroundColor: _cardColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(8.0)),
        side: BorderSide(color: _borderColor, width: 1.0),
      ),
    );
  }
}

/// Widget que contiene el contenido de la columna derecha (experiencia y estudios).
///
/// Combina las secciones de experiencia y estudios en un solo widget para
/// la estructura del diseño.
class _RightColumnContent extends StatelessWidget {
  const _RightColumnContent();

  @override
  Widget build(BuildContext context) {
    return const Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _TopRightSection(),
        SizedBox(height: 24),
        _ExperienceSection(),
        SizedBox(height: 24),
        _StudiesSection(),
      ],
    );
  }
}

/// Widget para la sección de perfil y resumen.
///
/// Muestra un texto descriptivo que resume el perfil profesional.
class _TopRightSection extends StatelessWidget {
  const _TopRightSection();

  static const Color _textColor = Color(0xFF333333);

  @override
  Widget build(BuildContext context) {
    return const Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Estudiante de Ingeniería de Software (sexto semestre) con más de dos años de experiencia en recolección y análisis de datos, marketing directo, encuestas remotas y soporte administrativo. Capacidad para redactar informes técnicos, representar productos y trabajar en proyectos académicos.',
          style: TextStyle(color: _textColor, fontSize: 16),
        ),
        SizedBox(height: 12),
        Text(
          'Habilidades tecnológicas, actitud proactiva y buena comunicación. Busco un empleo remoto o presencial donde pueda aplicar mis competencias y continuar desarrollándome profesionalmente.',
          style: TextStyle(color: _textColor, fontSize: 16),
        ),
      ],
    );
  }
}

/// Widget para la sección de experiencia laboral.
///
/// Contiene una lista de `_ExperienceItem` para cada trabajo.
class _ExperienceSection extends StatelessWidget {
  const _ExperienceSection();

  static const Color _textColor = Color(0xFF333333);

  @override
  Widget build(BuildContext context) {
    return const Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Experiencia laboral',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: _textColor,
          ),
        ),
        SizedBox(height: 16),
        _ExperienceItem(
          period: 'Ene 2025 - Jun 2025',
          position: 'Asistente de análisis y gestión de datos',
          company: 'Proyecto comunitario en zona rural',
          description:
              'Apoyo en la recolección, organización y análisis de datos de iniciativas locales. Sistematización de información sobre proyectos educativos y sociales desarrollados por líderes comunitarios. Elaboración de gráficos e informes en Excel y Word para presentar resultados a organizaciones aliadas. Trabajo colaborativo con docentes y representantes de la comunidad para documentar evidencias y resultados. Manejo responsable de bases de datos físicas y digitales.',
        ),
        _ExperienceItem(
          period: 'Nov 2024 - Ene 2025',
          position: 'Asesor ventas y marketing directo',
          company: 'Visión y marketing',
          description:
              'Promoción directa de productos a clientes en supermercados y tiendas. Ejecución de estrategias de marketing para aumentar la visibilidad del producto. Recomendación personalizada de productos según las necesidades del cliente. Registro de resultados y observaciones para retroalimentación de la marca.',
        ),
        _ExperienceItem(
          period: 'Mar 2023 - Abr 2024',
          position: 'Encuestador telefónico remoto',
          company: 'Centro Nacional de Consultoría CNC',
          description:
              'Apoyo en investigaciones y recopilación de datos. Atención a clientes y encuestados para estudios de mercado. Organización y procesamiento de información para análisis de datos.',
        ),
        _ExperienceItem(
          period: 'Feb 2023 - Actualidad',
          position: 'Monitor de Paz y convivencia humana',
          company: 'Laboratorio de paz',
          description:
              'Formación en estrategias de mediación de conflictos y construcción de paz en la comunidad. Implementación de proyectos orientados a la prevención del delito y la convivencia pacífica. Desarrollo de iniciativas de sensibilización y resolución pacífica de conflictos para los jóvenes de mi comunidad.',
        ),
      ],
    );
  }
}

/// Widget para un elemento de experiencia laboral individual.
///
/// Muestra el período, el puesto, la compañía y la descripción del trabajo.
class _ExperienceItem extends StatelessWidget {
  /// El período de tiempo del trabajo.
  final String period;

  /// La posición o cargo ocupado.
  final String position;

  /// El nombre de la compañía.
  final String company;

  /// Una descripción de las responsabilidades y logros.
  final String description;

  const _ExperienceItem({
    required this.period,
    required this.position,
    required this.company,
    required this.description,
  });

  static const Color _textColor = Color(0xFF333333);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 24.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            period,
            style: TextStyle(
              color: _textColor.withOpacity(0.6),
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            position,
            style: const TextStyle(
              color: _textColor,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            company,
            style: TextStyle(
              color: _textColor.withOpacity(0.6),
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            description,
            style: TextStyle(
              color: _textColor.withOpacity(0.8),
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }
}

/// Widget para la sección de estudios.
///
/// Contiene una lista de `_StudiesItem` para cada estudio o grado académico.
class _StudiesSection extends StatelessWidget {
  const _StudiesSection();

  static const Color _textColor = Color(0xFF333333);

  @override
  Widget build(BuildContext context) {
    return const Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Estudios',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: _textColor,
          ),
        ),
        SizedBox(height: 16),
        _StudiesItem(
          period: '2022 - Actualidad',
          title: 'Ingeniería de Software',
          institution: 'Universidad Tecnologico de Antioquia',
        ),
      ],
    );
  }
}

/// Widget para un elemento de estudio individual.
///
/// Muestra el período, el título del estudio y la institución.
class _StudiesItem extends StatelessWidget {
  /// El período de tiempo del estudio.
  final String period;

  /// El título del grado o estudio.
  final String title;

  /// El nombre de la institución educativa.
  final String institution;

  const _StudiesItem({
    required this.period,
    required this.title,
    required this.institution,
  });

  static const Color _textColor = Color(0xFF333333);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            period,
            style: TextStyle(
              color: _textColor.withOpacity(0.6),
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            title,
            style: const TextStyle(
              color: _textColor,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            institution,
            style: TextStyle(
              color: _textColor.withOpacity(0.6),
              fontSize: 16,
            ),
          ),
        ],
      ),
    );
  }
}

/// Widget para la sección de información personal en el diseño móvil.
///
/// Similar a `_buildPersonalInformationSection`, pero adaptado para el
/// diseño vertical de los móviles.
class _PersonalInformationMobile extends StatelessWidget {
  const _PersonalInformationMobile();

  static const Color _cardColor = Color(0xFFE0E0E0);
  static const Color _textColor = Color(0xFF333333);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: _cardColor,
      padding: const EdgeInsets.all(32.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Center(
            child: CircleAvatar(
              radius: 80,
              // Nota: Asegúrate de que la imagen esté en `assets/imagenes/`
              // y de que la ruta esté declarada en `pubspec.yaml`.
              backgroundImage:
                  AssetImage('assets/imagenes/mi_foto_de_perfil.jpg'),
            ),
          ),
          const SizedBox(height: 16),
          const Center(
            child: Text(
              'Luis Eduardo',
              style: TextStyle(
                color: _textColor,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Center(
            child: Text(
              'Cartagena Romero',
              style: TextStyle(
                color: _textColor.withOpacity(0.8),
                fontSize: 18,
              ),
            ),
          ),
          Divider(color: _textColor.withOpacity(0.5)),
          const _ContactInfo(),
          Divider(color: _textColor.withOpacity(0.5)),
          const Text(
            'Redes y enlaces',
            style: TextStyle(
              color: _textColor,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          const _SocialLink(label: 'www.facebook.com/...'),
          Divider(color: _textColor.withOpacity(0.5)),
          const Text(
            'Habilidades',
            style: TextStyle(
              color: _textColor,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          const _SkillsList(),
        ],
      ),
    );
  }
}
