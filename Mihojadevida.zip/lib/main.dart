import 'package:flutter/material.dart';
import 'package:mihojadevida/config/router/app_router.dart';

/// La función principal que se ejecuta al iniciar la aplicación.
///
/// Llama a [runApp] para inflar y mostrar el widget raíz de la aplicación,
/// que en este caso es.
void main() {
  runApp(const MyApp());
}

/// El widget raíz de la aplicación.
///
/// Este widget es el punto de entrada de la interfaz de usuario.
/// Se encarga de configurar el tema y el enrutamiento de la aplicación.
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // [MaterialApp.router] es el widget principal para aplicaciones que usan
    // un sistema de enrutamiento como go_router.
    return MaterialApp.router(
      // [routerConfig] es la propiedad que se usa para pasar la configuración
      // del enrutador de go_router.
      routerConfig: appRouter,

      // Título de la aplicación, que se muestra en la barra de tareas de la
      // ventana en plataformas de escritorio o en el historial de aplicaciones
      // recientes en móviles.
      title: 'Hoja de Vida',

      // Desactiva la etiqueta de "DEBUG" que aparece en la esquina superior
      // derecha de la pantalla.
      debugShowCheckedModeBanner: false,
    );
  }
}
